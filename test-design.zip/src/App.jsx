import React from 'react'
import Home from './pages/Home'
import { BrowserRouter, createBrowserRouter, Route, Routes } from 'react-router-dom'

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={Home} />
        </Routes>
      </BrowserRouter>
      <Home />
    </div>
  )
}

export default App
