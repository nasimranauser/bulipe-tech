import React from 'react'
import Notice from '../components/Notice'
import '../App.css'
import Menu from '../components/Menu'
import Banar from '../components/Banar'
import Community from '../components/Community'
import Work from '../components/Work'
import Programs from '../components/Program'

function Home() {
  return (
    <div>
      <Notice />
      <Menu />
      <Banar />
      <Community />
      <Work />
      <Programs />
    </div>
  )
}

export default Home
