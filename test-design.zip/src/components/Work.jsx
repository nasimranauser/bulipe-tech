import React from 'react'
import Heading from './Heading'
import group1 from '../icons/Group47.png'
import group2 from '../icons/Group48.png'
import group3 from '../icons/Group49.png'

function Work() {
  return (
    <section className='work-section'>
        <div className="page-wrapper">
        <div className="heading-wrap">
        <Heading heading={"How dose it Work?"} />
        <span className='line lbg1'></span>
        </div>
        
        <div className="work-content">
                <div className="work-item">
                    <div className='absshadow'></div>
                    <div className="line lbg1"></div>
                    <div className="ico">
                        <img src={group1} alt="Group 1" />
                    </div>
                     <h4>Training</h4>
                     <p>Our training programs, tailored to each subject matter and specialized courses, last at least 3 months and take place in our physical venues. Access to all course materials will be provided through the Bulipe App/repository, ensuring a comprehensive learning experience for all participants.</p>
                </div>
                <div className="work-item">
                <div className='absshadow'></div>
                    <div className="line lbg2"></div>
                    <div className="ico">
                        <img src={group2} alt="Group 1" />
                    </div>
                     <h4>Certification</h4>
                     <p>Upon completion of your desired course and training, each trainee must attend a central examination at their respective geographical headquarters of Bulipe. Upon passing, trainee graduates receive industry-recognized certifications trusted by employers globally.</p>
                </div>
                <div className="work-item">
                <div className='absshadow'></div>
                    <div className="line lbg3"></div>
                    <div className="ico">
                        <img src={group3} alt="Group 1" />
                    </div>
                     <h4>Employment</h4>
                     <p>We guarantee confirmed job prospects and a base salary of BDT 30,000 for all Bulipe trainee graduates through our vast alumni network, partnerships with 350+ global businesses across Europe, America, Asia, and Africa.</p>
                </div>
        </div>

        </div>
    </section>
  )
}

export default Work
