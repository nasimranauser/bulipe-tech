import React from 'react'
import Heading from './Heading'
import electric from '../icons/Img.png'
import readbtn from '../icons/readbtn.png'

function Community() {
  return (
    <section className='commiunity-section'>
        <div className="page-wrapper">
        <div className="heading-wrap">
        <Heading heading={"What We Do?"} />
        <span className='line'></span>
        </div>
        
        <div className="comminunity-content">
            <div className="left">
                    <h4>Bulipe Tech is a dynamic and innovative company</h4>
                    <p>We empower individuals to unlock career opportunities through our proven Digital Skill Development program. Partnering with 300 local organisations and 3,000+ global partners in 21 countries, we provide access to top U.S. certifications and salary-based employment starting at $250, with the potential to exceed $3,000 through continuous up-skilling.</p>
                    <div className="btn-field">
                        <a href="#">Read More <img src={readbtn} alt="Read More" /></a>
                    </div>
            </div>
            <div className="righ">
                <img src={electric} alt="Electric" />
            </div>
        </div>

        </div>
    </section>
  )
}

export default Community
