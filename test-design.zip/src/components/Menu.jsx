import React from 'react'
import logo from '../icons/logo.png'
import usercircle from '../icons/Fill.png'

function Menu() {
  return (
    <div className='page-wrapper'>
    <section className='menu_section'>
       <div className="logo">
        <img src={logo} alt="" />
       </div>
        <nav>
            <ul>
                <li><a href="#"></a>HOME</li>
                <li><a href="#"></a>ABOUT US</li>
                <li><a href="#"></a>PROGRAMS</li>
                <li><a href="#"></a>LOCATIONS</li>
                <li><a href="#"></a>CAREER AND PLACEMENT</li>
                <li><a href="#"></a>CONTACT US</li>
            </ul>
        </nav>
        <div className="button">
            <a href="#" className='primarybutton'>Sign Up &nbsp; <img src={usercircle} alt="User" /></a>
        </div>
    </section>
    </div>
  )
}

export default Menu
