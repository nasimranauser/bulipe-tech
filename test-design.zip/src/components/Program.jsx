import React, { useState } from 'react'
import Heading from './Heading'
import programbg from '../icons/programbg.png'
import sdev from '../icons/self-development.png'
import cert from '../icons/certificate.png'
import reso from '../icons/resources.png'
import fill2 from '../icons/Fill2.png'
// rect. icon
import r1 from '../icons/r1.png'
import r2 from '../icons/r2.png'
import r3 from '../icons/r3.png'
import r4 from '../icons/r4.png'
import r5 from '../icons/r5.png'
import r6 from '../icons/r6.png'
import start from '../icons/start.png'

function Programs() {
    const [active1, setActive1] = useState(true)
    const [active2, setActive2] = useState(false)
    const [active3, setActive3] = useState(false)

    const skill1 = ()=>{
        setActive1(true)
        setActive2(false)
        setActive3(false)
    }
    const skill2 = ()=>{
        setActive2(true)
        setActive1(false)
        setActive3(false)
    }
    const skill3 = ()=>{
        setActive3(true)
        setActive1(false)
        setActive2(false)
    }
  return (
    <section className='program-section'>
        <div className="page-wrapper">
        <div className="heading-wrap">
        <Heading heading={"Our Programs"} />
        <span className='line'></span>
        </div>
        
        <div className="program-content">
            {/* tabs */}
            <div className="tabs">
              <div className={active1?"tabcontent active":"tabcontent"} onClick={skill1}>
                <img src={sdev} alt="Skill development" />
                 <p>Digital Skills Development</p>
              </div>
              <div className={active2?"tabcontent active":"tabcontent"} onClick={skill2}>
                <img src={cert} alt="Digital skill development" />
                 <p>Skills Development</p>
              </div>
              <div className={active3?"tabcontent active":"tabcontent"} onClick={skill3}>
                <img src={reso} alt="Resource development" />
                 <p>All</p>
              </div>
            </div>
                <div className="program-items">
                        <div className="pitem">
                            <img src={r1} alt="" />
                            <p>IT Support Specialist</p>
                            <div className="middle mt-2">
                                <div className="p1">
                                    <span> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> </span>&nbsp;&nbsp;&nbsp;
                                    <span>5.0 (255)</span>
                                </div>
                                <div className="p2">
                                    <p>$300</p>
                                </div>
                            </div>
                            <div className="middle mt-2">
                                <p className='minfo'>More Info <span className='ml-3'></span> <img src={fill2} alt="fill" /></p>
                                <button className='primary-button'>Enroll Now</button>
                            </div>
                        </div>

                        <div className="pitem">
                            <img src={r2} alt="" />
                            <p>IT Support Specialist</p>
                            <div className="middle mt-2">
                                <div className="p1">
                                    <span> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" />  </span>&nbsp;&nbsp;&nbsp;
                                    <span>5.0 (255)</span>
                                </div>
                                <div className="p2">
                                    <p>$300</p>
                                </div>
                            </div>
                            <div className="middle mt-2">
                                <p className='minfo'>More Info <span className='ml-3'></span> <img src={fill2} alt="fill" /></p>
                                <button className='primary-button'>Enroll Now</button>
                            </div>
                        </div>

                        <div className="pitem">
                            <img src={r3} alt="" />
                            <p>IT Support Specialist</p>
                            <div className="middle mt-2">
                                <div className="p1">
                                    <span> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" />  </span>&nbsp;&nbsp;&nbsp;
                                    <span>5.0 (255)</span>
                                </div>
                                <div className="p2">
                                    <p>$300</p>
                                </div>
                            </div>
                            <div className="middle mt-2">
                                <p className='minfo'>More Info <span className='ml-3'></span> <img src={fill2} alt="fill" /></p>
                                <button className='primary-button'>Enroll Now</button>
                            </div>
                        </div>


                        <div className="pitem">
                            <img src={r4} alt="" />
                            <p>IT Support Specialist</p>
                            <div className="middle mt-2">
                                <div className="p1">
                                    <span> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" />  </span>&nbsp;&nbsp;&nbsp;
                                    <span>5.0 (255)</span>
                                </div>
                                <div className="p2">
                                    <p>$300</p>
                                </div>
                            </div>
                            <div className="middle mt-2">
                                <p className='minfo'>More Info <span className='ml-3'></span> <img src={fill2} alt="fill" /></p>
                                <button className='primary-button'>Enroll Now</button>
                            </div>
                        </div>


                        <div className="pitem">
                            <img src={r5} alt="" />
                            <p>IT Support Specialist</p>
                            <div className="middle mt-2">
                                <div className="p1">
                                    <span> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" />  </span>&nbsp;&nbsp;&nbsp;
                                    <span>5.0 (255)</span>
                                </div>
                                <div className="p2">
                                    <p>$300</p>
                                </div>
                            </div>
                            <div className="middle mt-2">
                                <p className='minfo'>More Info <span className='ml-3'></span> <img src={fill2} alt="fill" /></p>
                                <button className='primary-button'>Enroll Now</button>
                            </div>
                        </div>


                        <div className="pitem">
                            <img src={r6} alt="" />
                            <p>IT Support Specialist</p>
                            <div className="middle mt-2">
                                <div className="p1">
                                    <span> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" /> <img src={start} alt="" />  </span>&nbsp;&nbsp;&nbsp;
                                    <span>5.0 (255)</span>
                                </div>
                                <div className="p2">
                                    <p>$300</p>
                                </div>
                            </div>
                            <div className="middle mt-2">
                                <p className='minfo'>More Info <span className='ml-3'></span> <img src={fill2} alt="fill" /></p>
                                <button className='primary-button'>Enroll Now</button>
                            </div>
                        </div>
                </div>
                
        </div>

        </div>
    </section>
  )
}

export default Programs
