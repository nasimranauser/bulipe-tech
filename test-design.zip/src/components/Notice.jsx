import React from 'react'
import percentage from '../icons/banner.png'
// <section className='notice-section'></section>
 import cancel from '../icons/cancel.png'

function Notice() {
  return (
    <section className='notice'>
       <div className="page-wrapper">
<div className="grid">
<h1>100%</h1>
       <div className="round">
        <h6><span>Scholarship</span> on all 
        of our programs</h6>
       </div>
       <p>Exclusively for the physically challenged, and third-gender communities!</p>
        <img src={cancel} alt="" />
</div>
       </div>
    </section>
  )
}

export default Notice
