import React from 'react'
import usercircle from '../icons/Fill.png'
import fill2 from '../icons/Fill2.png'
import vector from '../icons/Vectordeviced.png'
import vprocess from '../image/altra-violet-process.png'
// visible service icon
import vi1 from '../icons/icon_05.png'
import vi2 from '../icons/icon_06.png'
import vi3 from '../icons/icon_12.png'

function Banar() {
  return (
    <section className="banar-section">
        <div className='page-wrapper'>
            <div className="banar">
                <div className="banar-left">
                    <div className="top-graphics"></div>
                     <div className="wrap-heading">
                        <h2>ELEVATING</h2>
                        <h1>IT Service Industry with Digital Skills
                        Development</h1>
                        <span className='graphics'></span>
                        <p>Bulipe Tech as a visionary agent collaborates with its parent companies from the USA and UK to bring forth a far-reaching Digital Skills Development project for the ever-changing workforce of Bangladesh.</p>
                     </div>
                     <div className="button-group">
                        <a className='primarybutton' href="#">Enroll Now <img src={usercircle} alt="" /> </a>
                        <a className='poutline-button' href="#">Read More <img src={fill2} alt="" /> </a>
                     </div>
                    <div className="bottom-graphics"></div>
                </div>
                <div className="banar-right">
                    <div className="wrap-right">
                        <img src={vprocess} alt="Violet Process" />
                        {/* <div className="div-shape">
                        <img src={Vectordeviced} alt="Violet Process" />
                        </div> */}
                    </div>
                </div>
            </div>
            {/* Visible services */}
            <div className="visible-services">
                 <div className="content">
                    <div className="icon">
                    <img src={vi1} alt="" />
                    </div>
                    <h5>
                    Master In-Demand Digital Skills to Advance Your Career
                    </h5>
                    <p>Unlock career opportunities through our industry-recognized Digital Skill Development program. Begin your journey today with 300 local partners to stay ahead of the curve!</p>
                 </div>
                  <div className="content">
                    <div className="icon">
                    <img src={vi2} alt="" />
                    </div>
                    <h5>
                    Earn Vendor Certifications and Join Us
                    </h5>
                    <p>Our post-training assessments connect you with leading U.S. certification providers. Join over 3,000 global partners across 21+ countries and begin your career today!</p>
                 </div>
                 <div className="content">
                    <div className="icon">
                    <img src={vi3} alt="" />
                    </div>
                    <h5>
                    Start Earning BDT 30,000 Monthly and Grow Your Skills
                    </h5>
                    <p>Salary-based employment starting at BDT 30,000, with the potential to exceed BDT 3,00,000+ as you up-skill and master new digital skills. Your earning potential is limitless.</p>
                 </div>
            </div>
      </div>
    </section>
  )
}

export default Banar
